﻿Imports System.Data.OleDb
Module Module1
    Public con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\RegisterLogin1243.accdb;")


    Function Connect1()
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Return True
    End Function
End Module
